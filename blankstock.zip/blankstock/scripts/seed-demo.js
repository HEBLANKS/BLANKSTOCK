// Fills a database with made-up demo data so you can click around before connecting real stores.
// Usage: DB_PATH=data/demo.db node scripts/seed-demo.js
const path = require('path'), fs = require('fs');
if (fs.existsSync(path.join(__dirname, '..', '.env'))) process.loadEnvFile(path.join(__dirname, '..', '.env'));
const { db, setSetting } = require('../src/db');
const stock = require('../src/stock');
if (db.prepare('SELECT COUNT(*) n FROM clients').get().n) { console.log('Database already has clients — not seeding.'); process.exit(0); }

setSetting('biz_name', 'Your Print Shop'); setSetting('biz_email', 'accounts@example.com'); setSetting('vat_rate', '20');
setSetting('biz_address', '1 Example Street\nSouthport'); setSetting('bank_details', 'Account name: Your Print Shop\nSort code: 00-00-00  Account: 00000000');
setSetting('payment_terms', 'Payment due within 7 days. Blanks are ordered once paid.');

const brands = [
  { name: 'Northside Club', markup: 10, fee: 5, styles: [['AT001', 'AWDis 150 tee', ['Jet Black', 'Arctic White'], ['S', 'M', 'L', 'XL', '2XL'], 2.32], ['RX350', 'Pro RTX hoodie', ['Navy'], ['S', 'M', 'L', 'XL'], 7.49]] },
  { name: 'Low Tide Goods', markup: 15, fee: 0, styles: [['AT001', 'AWDis 150 tee', ['Sand'], ['S', 'M', 'L', 'XL'], 2.32]] },
  { name: 'Heavy Hands', markup: 10, fee: 7.5, styles: [['RX350', 'Pro RTX hoodie', ['Jet Black', 'Charcoal'], ['M', 'L', 'XL', '2XL'], 7.49]] },
];
let oid = 5000;
for (const [bi, br] of brands.entries()) {
  const cid = db.prepare('INSERT INTO clients(name,email,markup_pct,handling_fee) VALUES(?,?,?,?)').run(br.name, `hello@${br.name.toLowerCase().replace(/\W+/g, '')}.com`, br.markup, br.fee).lastInsertRowid;
  const shop = br.name.toLowerCase().replace(/\W+/g, '-') + '.myshopify.com';
  const sid = db.prepare("INSERT INTO stores(client_id,shop,auth_mode,status,webhooks_registered,last_synced_at) VALUES(?,?, 'token','connected',1,datetime('now','-4 minutes'))").run(cid, shop).lastInsertRowid;
  const blanks = [];
  for (const [code, name, colours, sizes, cost] of br.styles) for (const c of colours) for (const s of sizes) {
    const id = db.prepare('INSERT INTO blanks(client_id,style_code,style_name,colour,size,unit_cost,reorder_point,par_level) VALUES(?,?,?,?,?,?,?,?)').run(cid, code, name, c, s, cost, 2, s === 'M' || s === 'L' ? 12 : 8).lastInsertRowid;
    stock.addMovement(id, [6, 10, 10, 6, 3][sizes.indexOf(s) % 5], 'intake', { note: 'Deposit stock' });
    blanks.push({ id, code, c, s });
    db.prepare('INSERT INTO variant_map(store_id,variant_id,blank_id) VALUES(?,?,?)').run(sid, `gid://shopify/ProductVariant/${id}`, id);
  }
  for (let i = 0; i < 14 + bi * 4; i++) {
    const n = 1 + (i % 3 === 0);
    const lines = Array.from({ length: n }, (_, k) => { const b = blanks[(i * 7 + k * 3 + bi) % blanks.length]; return { lineId: `L${oid}-${k}`, sku: null, variantId: `gid://shopify/ProductVariant/${b.id}`, title: `${br.name.split(' ')[0]} ${b.code === 'RX350' ? 'Hoodie' : 'Tee'}`, variantTitle: `${b.c} / ${b.s}`, qty: 1 + ((i + k) % 4 === 0) }; });
    if (bi === 0 && i === 3) lines.push({ lineId: `L${oid}-x`, sku: 'NS-CAP-BLK', variantId: 'gid://shopify/ProductVariant/999', title: 'Northside Cap', variantTitle: 'Black', qty: 1 });
    oid++;
    stock.ingestOrder(sid, { shopifyId: `gid://shopify/Order/${oid}`, name: `#${1000 + oid - 5000}`, placedAt: new Date(Date.now() - (30 - i) * 36e5).toISOString(), cancelled: false, adminUrl: null, lines });
    if (i < 6) db.prepare("UPDATE orders SET status='dispatched' WHERE shopify_id=?").run(`gid://shopify/Order/${oid}`);
  }
}
console.log('Demo data added.');
