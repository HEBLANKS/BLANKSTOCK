// BlankStock front end — plain JS, no build step.
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => '£' + (Number(n) || 0).toFixed(2);
const SIZES = ['XXS','XS','S','M','L','XL','2XL','3XL','4XL','5XL','6XL','7XL','8XL','OS'];
const sizeRank = s => { const i = SIZES.indexOf(String(s).toUpperCase()); return i < 0 ? 99 : i; };
const when = s => s ? new Date(s.includes('T') ? s : s.replace(' ', 'T') + 'Z').toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';

const state = { view: 'dashboard', client: null, orderFilter: 'ready', clients: [] };
try { Object.assign(state, JSON.parse(localStorage.getItem('bs') || '{}')); } catch {}
const save = () => { try { localStorage.setItem('bs', JSON.stringify({ view: state.view, client: state.client, orderFilter: state.orderFilter })); } catch {} };

async function api(path, opts = {}) {
  const r = await fetch(path, { method: opts.method || (opts.body ? 'POST' : 'GET'), headers: { 'Content-Type': 'application/json' }, body: opts.body ? JSON.stringify(opts.body) : undefined });
  if (r.status === 401 && !path.includes('login')) { showLogin(); throw new Error('Please log in'); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `Error ${r.status}`);
  return j;
}
function toast(msg, bad) { const t = $('#toast'); t.textContent = msg; t.className = 'toast' + (bad ? ' bad' : ''); clearTimeout(t._h); t._h = setTimeout(() => t.classList.add('hidden'), bad ? 6000 : 2600); }
const run = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };
function modal(html) { $('#modalBody').innerHTML = html; $('#modal').classList.remove('hidden'); return $('#modalBody'); }
const closeModal = () => $('#modal').classList.add('hidden');
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal' || e.target.dataset.close !== undefined) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

function showLogin() { $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); }
$('#loginForm').addEventListener('submit', run(async e => {
  e.preventDefault(); $('#loginErr').textContent = '';
  try { await api('/api/login', { body: { password: e.target.password.value } }); } catch (x) { $('#loginErr').textContent = x.message; return; }
  $('#login').classList.add('hidden'); boot();
}));

async function loadClients() { state.clients = await api('/api/clients'); if (!state.clients.find(c => c.id === state.client)) state.client = state.clients[0]?.id || null; }
const clientPicker = (all = false) => `<select id="clientPick">${all ? '<option value="">All clients</option>' : ''}${state.clients.map(c => `<option value="${c.id}" ${c.id === state.client ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>`;
function bindClientPicker(allowAll) {
  const el = $('#clientPick'); if (!el) return;
  if (allowAll && state.clientAll) el.value = '';
  el.onchange = () => { state.clientAll = !el.value; if (el.value) state.client = +el.value; save(); render(); };
}
const noClients = () => `<div class="card empty">Add your first client under <a href="#" onclick="go('clients');return false">Clients &amp; stores</a>.</div>`;

function go(v) { state.view = v; save(); render(); }
$$('#nav a').forEach(a => a.onclick = () => go(a.dataset.view));
$('#syncAll').onclick = run(async () => { $('#syncAll').disabled = true; try { const r = await api('/api/sync-all', { body: {} }); const bad = r.filter(x => x.error); toast(bad.length ? `${bad.length} store(s) failed: ${bad[0].shop} — ${bad[0].error}` : `Synced ${r.length} store(s), ${r.reduce((s, x) => s + (x.created || 0), 0)} new orders`, bad.length); render(); } finally { $('#syncAll').disabled = false; } });

async function render() {
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.view === state.view));
  const v = $('#view');
  try { await (VIEWS[state.view] || VIEWS.dashboard)(v); } catch (e) { v.innerHTML = `<div class="card err">${esc(e.message)}</div>`; }
  api('/api/unmapped').then(u => { const b = $('#unmappedBadge'); b.textContent = u.length; b.classList.toggle('hidden', !u.length); }).catch(() => {});
}

const VIEWS = {};

// ---------------- Dashboard ----------------
VIEWS.dashboard = async v => {
  const s = await api('/api/summary');
  if (!s.clients.length) { v.innerHTML = `<h2>Dashboard</h2>${noClients()}`; return; }
  const storeIssues = s.stores.filter(x => x.status !== 'connected');
  v.innerHTML = `<h2>Dashboard</h2>
  ${storeIssues.length ? `<div class="card" style="margin-bottom:12px;border-color:var(--low)"><b>Stores needing attention:</b> ${storeIssues.map(x => `${esc(x.client)} (${esc(x.shop)}): ${esc(x.status_note || x.status)}`).join(' · ')}</div>` : ''}
  <div class="grid">${s.clients.map(c => `<div class="card">
    <div class="row spread"><h3 style="margin:0">${esc(c.name)}</h3><span class="muted">${c.on_hand} blanks · ${money(c.stock_value)}</span></div>
    <div class="kpis">
      <div class="kpi"><b>${c.open_orders}</b><span>open orders</span></div>
      <div class="kpi ${c.blocked_orders ? 'bad' : ''}"><b>${c.blocked_orders}</b><span>blocked</span></div>
      <div class="kpi ${c.short_units ? 'bad' : ''}"><b>${c.short_units}</b><span>units short</span></div>
      <div class="kpi ${c.low_skus ? 'warn' : ''}"><b>${c.low_skus}</b><span>sizes low</span></div>
      <div class="kpi ${c.unmapped_lines ? 'warn' : ''}"><b>${c.unmapped_lines}</b><span>unmapped lines</span></div>
      <div class="kpi"><b>${c.to_invoice}</b><span>to top up</span></div>
    </div>
    <div class="row" style="margin-top:12px">
      <button class="btn small" data-c="${c.id}" data-go="orders">Orders</button>
      <button class="btn small" data-c="${c.id}" data-go="stock">Stock</button>
      ${c.to_invoice ? `<button class="btn small primary" data-c="${c.id}" data-go="topups">Invoice top-up</button>` : ''}
    </div></div>`).join('')}</div>`;
  $$('[data-go]', v).forEach(b => b.onclick = () => { state.client = +b.dataset.c; state.clientAll = false; if (b.dataset.go === 'orders') state.orderFilter = 'blocked'; go(b.dataset.go); });
};

// ---------------- Orders ----------------
VIEWS.orders = async v => {
  const F = [['ready', 'Ready to print'], ['blocked', 'Blocked'], ['printed', 'Printed'], ['dispatched', 'Dispatched'], ['cancelled', 'Cancelled'], ['', 'All']];
  const q = new URLSearchParams({ status: state.orderFilter || '' });
  if (!state.clientAll && state.client) q.set('client', state.client);
  if (state.q) q.set('q', state.q);
  const orders = await api('/api/orders?' + q);
  v.innerHTML = `<div class="row spread"><h2>Orders</h2><div class="row">${clientPicker(true)}<input id="q" placeholder="Search order, product, SKU" value="${esc(state.q || '')}"></div></div>
  <div class="chips">${F.map(([k, l]) => `<span class="chip ${state.orderFilter === k ? 'on' : ''}" data-f="${k}">${l}</span>`).join('')}</div>
  <div class="card">
    <div class="row spread" style="margin-bottom:6px"><label class="row" style="flex-direction:row;color:var(--ink)"><input type="checkbox" id="all"> Select all (${orders.length})</label>
    <div class="row"><button class="btn small" data-s="printed">Mark printed</button><button class="btn small" data-s="dispatched">Mark dispatched</button><button class="btn small ghost" data-s="new">Back to new</button></div></div>
    ${orders.length ? orders.map(o => `<div class="order">
      <input type="checkbox" class="sel" value="${o.id}">
      <div><div class="row"><b>${esc(o.name)}</b><span class="muted">${esc(o.client)} · ${when(o.placed_at)}</span>
        ${o.cancelled ? '<span class="pill short">cancelled</span>' : o.blocked ? '<span class="pill short">blocked</span>' : `<span class="pill ${o.status === 'new' ? 'ok' : ''}">${o.status === 'new' ? 'ready' : o.status}</span>`}</div>
        <div class="lines">${o.lines.map(l => `<div><span>${l.qty}× ${esc(l.title)}${l.variant_title ? ' — ' + esc(l.variant_title) : ''}</span>
          ${!l.processed ? '<span class="flag">no blank mapped</span>' : !l.blank_id ? '<span>not a tracked blank</span>' : `<span>→ ${esc(l.style_code)} ${esc(l.colour)} ${esc(l.size)}${l.units > 1 ? ` ×${l.units}` : ''}</span>`}
          ${l.short_qty ? `<span class="flag">${l.short_qty} short</span>` : ''}</div>`).join('')}</div></div>
      <div>${o.admin_url ? `<a href="${esc(o.admin_url)}" target="_blank" rel="noopener" class="btn small ghost">Shopify ↗</a>` : ''}</div></div>`).join('') : '<div class="empty">No orders here.</div>'}
  </div>`;
  bindClientPicker(true);
  $$('.chip', v).forEach(c => c.onclick = () => { state.orderFilter = c.dataset.f; save(); render(); });
  let t; $('#q').oninput = e => { clearTimeout(t); t = setTimeout(() => { state.q = e.target.value; render().then(() => { const i = $('#q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }); }, 350); };
  $('#all').onchange = e => $$('.sel', v).forEach(c => c.checked = e.target.checked);
  $$('[data-s]', v).forEach(b => b.onclick = run(async () => {
    const ids = $$('.sel:checked', v).map(c => +c.value); if (!ids.length) return toast('Tick some orders first');
    await api('/api/orders/status', { body: { ids, status: b.dataset.s } }); toast(`${ids.length} order(s) updated`); render();
  }));
};

// ---------------- Stock ----------------
VIEWS.stock = async v => {
  if (!state.clients.length) { v.innerHTML = `<h2>Stock</h2>${noClients()}`; return; }
  const rows = await api(`/api/clients/${state.client}/stock`);
  const groups = {}; const sizes = new Set();
  for (const r of rows) { const k = `${r.style_code}|${r.colour}`; (groups[k] ||= { style: r.style_code, name: r.style_name, colour: r.colour, cells: {} }).cells[r.size] = r; sizes.add(r.size); }
  const cols = [...sizes].sort((a, b) => sizeRank(a) - sizeRank(b));
  const tot = rows.reduce((a, r) => ({ on: a.on + Math.max(0, r.on_hand), short: a.short + Math.max(0, -r.on_hand), low: a.low + (r.status === 'low') }), { on: 0, short: 0, low: 0 });
  v.innerHTML = `<div class="row spread"><h2>Stock</h2><div class="row">${clientPicker()}<button class="btn primary" id="addBlanks">+ Add / book in blanks</button></div></div>
  <p class="muted">${tot.on} blanks on the shelf · <span style="color:var(--short)">${tot.short} short</span> · <span style="color:var(--low)">${tot.low} sizes at or below reorder point</span>. Click a cell to book stock in, count it, or change its settings. Small number = on order.</p>
  <div class="card tablewrap">${rows.length ? `<table class="matrix"><thead><tr><th>Style</th><th>Colour</th>${cols.map(s => `<th class="n" style="text-align:center">${esc(s)}</th>`).join('')}<th class="n">Total</th></tr></thead><tbody>
    ${Object.values(groups).map(g => `<tr><td><b>${esc(g.style)}</b><br><span class="muted">${esc(g.name || '')}</span></td><td>${esc(g.colour)}</td>
      ${cols.map(s => { const c = g.cells[s]; return c ? `<td class="cell ${c.status}" data-id="${c.id}" title="Reorder at ${c.reorder_point}, par ${c.par_level}">${c.on_hand}${c.on_order ? `<small>+${c.on_order}</small>` : ''}</td>` : '<td class="cell none">·</td>'; }).join('')}
      <td class="n">${Object.values(g.cells).reduce((s, c) => s + c.on_hand, 0)}</td></tr>`).join('')}
  </tbody></table>` : '<div class="empty">No blanks set up for this client yet. Add their styles, colours and sizes with “Add / book in blanks”.</div>'}</div>`;
  bindClientPicker();
  $('#addBlanks').onclick = () => addBlanksModal();
  $$('td.cell[data-id]', v).forEach(td => td.onclick = () => blankModal(rows.find(r => r.id === +td.dataset.id)));
};

function addBlanksModal() {
  const m = modal(`<h2>Add or book in blanks</h2>
  <p class="muted">Creates the blank if it's new, and books the quantity into stock (e.g. from a client deposit). Enter several sizes at once.</p>
  <form id="bf" class="form">
    <label>Style code<input name="style_code" placeholder="AT001" required></label>
    <label>Style name<input name="style_name" placeholder="AWDis 150 tee"></label>
    <label>Colour<input name="colour" placeholder="Jet Black" required></label>
    <label>Sizes<input name="size" placeholder="S M L XL 2XL" required></label>
    <label>Qty per size<input name="qty" type="number" value="0"></label>
    <label>Unit cost £<input name="unit_cost" type="number" step="0.01" value="0"></label>
    <label>Reorder at<input name="reorder_point" type="number" value="2"></label>
    <label>Top up to (par)<input name="par_level" type="number" value="10"></label>
  </form>
  <details><summary>…or paste a spreadsheet (CSV)</summary>
    <p class="muted">Columns: style_code, style_name, colour, size, qty, unit_cost, reorder_point, par_level, sku (sku optional — use it if the Shopify SKU should auto-map).</p>
    <textarea id="csv" placeholder="style_code,style_name,colour,size,qty,unit_cost,reorder_point,par_level&#10;AT001,AWDis 150 tee,Jet Black,M,24,2.32,4,24"></textarea></details>
  <div class="row" style="margin-top:12px"><button class="btn primary" id="go">Save</button><button class="btn ghost" data-close>Cancel</button></div>`);
  $('#go', m).onclick = run(async () => {
    const csv = $('#csv', m).value.trim();
    const body = csv ? { client_id: state.client, csv } : { client_id: state.client, ...Object.fromEntries(new FormData($('#bf', m))) };
    const r = await api('/api/blanks', { body }); closeModal(); toast(`${r.rows} blank(s) saved, ${r.units_booked} units booked in`); render();
  });
}

function blankModal(b) {
  const m = modal(`<h2>${esc(b.style_code)} · ${esc(b.colour)} · ${esc(b.size)}</h2>
  <p><span class="pill ${b.status}">${b.on_hand} on hand</span> ${b.on_order ? `<span class="pill">${b.on_order} on order</span>` : ''} <span class="muted">· ${b.used_30d} used in 30 days</span></p>
  <h3>Move stock</h3>
  <div class="row"><input id="mq" type="number" placeholder="Qty" style="width:90px">
    <select id="mk"><option value="intake">Book in (+)</option><option value="adjust">Adjust (+/−)</option><option value="set">Stock take (set count)</option></select>
    <input id="mn" placeholder="Note (optional)" style="flex:1"><button class="btn primary" id="mv">Apply</button></div>
  <h3>Settings</h3>
  <div class="form">
    <label>Style name<input id="sn" value="${esc(b.style_name || '')}"></label>
    <label>Unit cost £<input id="uc" type="number" step="0.01" value="${b.unit_cost}"></label>
    <label>Reorder at<input id="rp" type="number" value="${b.reorder_point}"></label>
    <label>Top up to (par)<input id="pl" type="number" value="${b.par_level}"></label>
    <label>Shopify SKU<input id="sk" value="${esc(b.sku || '')}"></label>
  </div>
  <div class="row" style="margin-top:10px"><button class="btn" id="sv">Save settings</button><button class="btn ghost danger" id="rm">Hide this blank</button><button class="btn ghost" data-close>Close</button></div>
  <h3>History</h3><div id="hist" class="tablewrap muted">Loading…</div>`);
  api(`/api/blanks/${b.id}/history`).then(h => $('#hist', m).innerHTML = h.length ? `<table><tr><th>When</th><th>Type</th><th class="n">Qty</th><th>Ref</th></tr>${h.map(x => `<tr><td>${when(x.created_at)}</td><td>${esc(x.kind)}</td><td class="n">${x.qty > 0 ? '+' : ''}${x.qty}</td><td>${esc(x.ref || '')} ${esc(x.note || '')}</td></tr>`).join('')}</table>` : 'No movements yet.');
  $('#mv', m).onclick = run(async () => {
    const k = $('#mk', m).value, qty = +$('#mq', m).value;
    if (!Number.isFinite(qty) || (!qty && k !== 'set')) return toast('Enter a quantity');
    const r = await api(`/api/blanks/${b.id}/move`, { body: { qty, kind: k === 'set' ? 'adjust' : k, mode: k === 'set' ? 'set' : '', note: $('#mn', m).value } });
    closeModal(); toast(`Now ${r.on_hand} on hand`); render();
  });
  $('#sv', m).onclick = run(async () => { await api(`/api/blanks/${b.id}`, { method: 'PUT', body: { style_name: $('#sn', m).value, unit_cost: $('#uc', m).value, reorder_point: $('#rp', m).value, par_level: $('#pl', m).value, sku: $('#sk', m).value, active: 1 } }); closeModal(); toast('Saved'); render(); });
  $('#rm', m).onclick = run(async () => { await api(`/api/blanks/${b.id}`, { method: 'PUT', body: { active: 0 } }); closeModal(); toast('Hidden'); render(); });
}

// ---------------- Mapping ----------------
const blankLabel = b => `${b.style_code} ${b.colour} ${b.size}`;
const blankOptions = (blanks, sel) => `<option value="">— pick blank —</option>` + blanks.map(b => `<option value="${b.id}" ${b.id === sel ? 'selected' : ''}>${esc(blankLabel(b))}</option>`).join('');

VIEWS.mapping = async v => {
  const [un, stores] = await Promise.all([api('/api/unmapped'), api('/api/stores')]);
  const clientIds = [...new Set([...un.map(u => u.client_id), ...stores.map(s => s.client_id)])];
  const blanksBy = Object.fromEntries(await Promise.all(clientIds.map(async id => [id, await api(`/api/clients/${id}/stock`)])));
  v.innerHTML = `<h2>Mapping</h2>
  <p class="muted">Tell BlankStock which blank each Shopify product variant is printed on. Once mapped, every future order for that variant takes the blank out of stock automatically.</p>
  <div class="card"><h3 style="margin-top:0">Waiting on a mapping (${un.length})</h3>
  ${un.length ? `<div class="tablewrap"><table><tr><th>Client</th><th>Product</th><th class="n">Qty waiting</th><th>Blank</th><th>Uses</th><th></th></tr>
    ${un.map((u, i) => `<tr><td>${esc(u.client)}</td><td>${esc(u.title)}${u.variant_title ? ' — ' + esc(u.variant_title) : ''}<br><span class="muted">${esc(u.sku || 'no SKU')}</span></td><td class="n">${u.qty} (${u.orders} orders)</td>
    <td><select data-i="${i}" class="ub">${blankOptions(blanksBy[u.client_id] || [])}</select></td><td><input type="number" min="1" value="1" class="uu" data-i="${i}" style="width:60px"></td>
    <td class="row">${u.variant_id ? `<button class="btn small primary um" data-i="${i}">Map</button>` : ''}<button class="btn small ghost ig" data-i="${i}" title="For products that aren't printed on a stocked blank, e.g. caps or stickers">Don't track</button></td></tr>`).join('')}</table></div>` : '<div class="empty">Nothing waiting. 👌</div>'}</div>
  <div class="card" style="margin-top:12px"><h3 style="margin-top:0">Map a whole store's products</h3>
  <div class="row"><select id="st">${stores.map(s => `<option value="${s.id}">${esc(s.client)} — ${esc(s.shop)}</option>`).join('')}</select><button class="btn" id="load" ${stores.length ? '' : 'disabled'}>Load products from Shopify</button></div>
  <div id="variants"></div></div>`;
  $$('.um', v).forEach(b => b.onclick = run(async () => {
    const i = +b.dataset.i, u = un[i], blank = +$(`.ub[data-i="${i}"]`, v).value;
    if (!blank) return toast('Pick a blank first');
    const r = await api('/api/map', { body: { store_id: u.store_id, variant_id: u.variant_id, blank_id: blank, units: $(`.uu[data-i="${i}"]`, v).value, label: `${u.title} — ${u.variant_title || ''}` } });
    toast(`Mapped · ${r.reprocessed} waiting line(s) now taken from stock`); render();
  }));
  $$('.ig', v).forEach(b => b.onclick = run(async () => { const u = un[+b.dataset.i]; await api('/api/ignore', { body: u }); toast('Won\'t ask about this product again'); render(); }));
  $('#load', v).onclick = run(async () => {
    const store = stores.find(s => s.id === +$('#st', v).value); const blanks = blanksBy[store.client_id] || [];
    $('#variants', v).innerHTML = '<p class="muted">Loading from Shopify…</p>';
    const vars = await api(`/api/stores/${store.id}/variants`);
    const byProduct = {}; vars.forEach(x => (byProduct[x.product_id] ||= { title: x.product, vars: [] }).vars.push(x));
    const styles = [...new Set(blanks.map(b => `${b.style_code}|${b.colour}`))];
    $('#variants', v).innerHTML = Object.entries(byProduct).map(([pid, p]) => `<div style="margin-top:14px" data-p="${esc(pid)}">
      <div class="row spread"><b>${esc(p.title)}</b><span class="row"><select class="auto"><option value="">Auto-match sizes to…</option>${styles.map(s => `<option>${esc(s.replace('|', ' · '))}</option>`).join('')}</select></span></div>
      <table>${p.vars.map(x => `<tr><td>${esc(x.title)}<br><span class="muted">${esc(x.sku || '')}</span></td><td><select class="vb" data-v="${esc(x.id)}" data-size="${esc(x.size || x.title)}" data-label="${esc(p.title + ' — ' + x.title)}">${blankOptions(blanks, x.map?.blank_id)}</select></td></tr>`).join('')}</table></div>`).join('')
      + `<div class="row" style="margin-top:14px"><button class="btn primary" id="saveMaps">Save all mappings</button></div>`;
    $$('.auto', v).forEach(sel => sel.onchange = () => {
      const [style, colour] = sel.value.split(' · '); if (!style) return;
      $$('.vb', sel.closest('[data-p]')).forEach(vb => {
        const size = String(vb.dataset.size).toUpperCase().replace(/^XXL$/, '2XL').replace(/^XXXL$/, '3XL');
        const hit = blanks.find(b => b.style_code === style && b.colour === colour && (b.size === size || size.split(/[\s/]+/).includes(b.size)));
        if (hit) vb.value = hit.id;
      });
    });
    $('#saveMaps', v).onclick = run(async () => {
      const items = $$('.vb', v).map(vb => ({ store_id: store.id, variant_id: vb.dataset.v, blank_id: +vb.value || null, label: vb.dataset.label }));
      const r = await api('/api/map', { body: items }); toast(`Saved · ${r.reprocessed} waiting line(s) taken from stock`); render();
    });
  });
};

// ---------------- Top-ups ----------------
VIEWS.topups = async v => {
  if (!state.clients.length) { v.innerHTML = `<h2>Top-ups</h2>${noClients()}`; return; }
  const client = state.clients.find(c => c.id === state.client);
  const [rows, invs] = await Promise.all([api(`/api/clients/${state.client}/stock`), api(`/api/invoices?client=${state.client}`)]);
  const need = rows.filter(r => r.suggest > 0 || r.on_hand < 0 || r.status === 'low');
  const price = r => Math.round(r.unit_cost * (1 + client.markup_pct / 100) * 100) / 100;
  v.innerHTML = `<div class="row spread"><h2>Top-ups</h2>${clientPicker()}</div>
  <div class="card"><h3 style="margin-top:0">What ${esc(client.name)} needs</h3>
  <p class="muted">Suggested qty covers anything sold without stock, plus enough to get back to par, minus anything already on an open invoice. Edit before creating. Markup ${client.markup_pct}% · handling ${money(client.handling_fee)} (set on the client).</p>
  ${need.length ? `<div class="tablewrap"><table><tr><th>Blank</th><th class="n">On hand</th><th class="n">On order</th><th class="n">Par</th><th class="n">Qty</th><th class="n">Unit £</th><th class="n">Line</th></tr>
    ${need.map(r => `<tr><td>${esc(blankLabel(r))}</td><td class="n"><span class="pill ${r.status}">${r.on_hand}</span></td><td class="n">${r.on_order}</td><td class="n">${r.par_level}</td>
    <td class="n"><input type="number" min="0" class="tq" data-id="${r.id}" value="${r.suggest}" style="width:70px"></td>
    <td class="n"><input type="number" step="0.01" class="tp" data-id="${r.id}" value="${price(r).toFixed(2)}" style="width:80px"></td><td class="n lt"></td></tr>`).join('')}
    <tr><td colspan="6" class="n"><b>Subtotal (ex VAT, inc handling)</b></td><td class="n"><b id="sub"></b></td></tr></table></div>
    <label style="margin-top:10px">Note on invoice<input id="note" placeholder="e.g. Covers orders #1041–#1058 that sold through deposit stock"></label>
    <div class="row" style="margin-top:10px"><button class="btn primary" id="mk">Create top-up invoice</button></div>` : '<div class="empty">Nothing needs topping up right now.</div>'}</div>
  <div class="card" style="margin-top:12px"><h3 style="margin-top:0">Invoices</h3>
  ${invs.length ? `<div class="tablewrap"><table><tr><th>No.</th><th>Date</th><th class="n">Units</th><th class="n">Total</th><th>Status</th><th>Stock arrived</th><th></th></tr>
    ${invs.map(i => `<tr><td><b>${esc(i.number)}</b></td><td>${esc(i.created_at.slice(0, 10))}</td><td class="n">${i.units}</td><td class="n">${money(i.total)}</td>
    <td><select class="is" data-id="${i.id}">${['draft', 'sent', 'paid', 'void'].map(s => `<option ${s === i.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
    <td>${i.received >= i.units ? '<span class="pill ok">all in</span>' : i.status === 'void' ? '—' : `${i.received}/${i.units} <button class="btn small rc" data-id="${i.id}">Book in</button>`}</td>
    <td class="row"><a class="btn small" href="/invoices/${i.id}" target="_blank">View / PDF</a><a class="btn small ghost" href="/invoices/${i.id}.csv">CSV</a></td></tr>`).join('')}</table></div>` : '<div class="empty">No invoices yet.</div>'}</div>`;
  bindClientPicker();
  const recalc = () => {
    let sub = 0; $$('.tq', v).forEach(q => { const p = +$(`.tp[data-id="${q.dataset.id}"]`, v).value || 0; const t = (+q.value || 0) * p; sub += t; q.closest('tr').querySelector('.lt').textContent = money(t); });
    if ($('#sub', v)) $('#sub', v).textContent = money(sub + (sub ? client.handling_fee : 0));
  };
  $$('.tq,.tp', v).forEach(i => i.oninput = recalc); recalc();
  if ($('#mk', v)) $('#mk', v).onclick = run(async () => {
    const lines = $$('.tq', v).map(q => ({ blank_id: +q.dataset.id, qty: +q.value, unit_price: $(`.tp[data-id="${q.dataset.id}"]`, v).value })).filter(l => l.qty > 0);
    const r = await api('/api/invoices', { body: { client_id: state.client, lines, notes: $('#note', v).value } });
    toast('Invoice created'); window.open(`/invoices/${r.id}`, '_blank'); render();
  });
  $$('.is', v).forEach(s => s.onchange = run(async () => { await api(`/api/invoices/${s.dataset.id}`, { method: 'PUT', body: { status: s.value } }); toast('Updated'); render(); }));
  $$('.rc', v).forEach(b => b.onclick = run(async () => {
    const inv = invs.find(i => i.id === +b.dataset.id);
    const m = modal(`<h2>Book in ${esc(inv.number)}</h2><p class="muted">Enter what actually arrived from the supplier. Back-ordered customer orders are cleared first.</p>
      <table><tr><th>Blank</th><th class="n">Outstanding</th><th class="n">Arrived</th></tr>${inv.lines.filter(l => l.qty > l.received_qty).map(l => `<tr><td>${esc(l.style_code)} ${esc(l.colour)} ${esc(l.size)}</td><td class="n">${l.qty - l.received_qty}</td><td class="n"><input type="number" min="0" max="${l.qty - l.received_qty}" value="${l.qty - l.received_qty}" data-l="${l.id}" style="width:70px"></td></tr>`).join('')}</table>
      <div class="row" style="margin-top:12px"><button class="btn primary" id="ok">Book into stock</button><button class="btn ghost" data-close>Cancel</button></div>`);
    $('#ok', m).onclick = run(async () => { const r = await api(`/api/invoices/${inv.id}/receive`, { body: { lines: $$('[data-l]', m).map(i => ({ id: +i.dataset.l, qty: +i.value })) } }); closeModal(); toast(`${r.units} units booked in`); render(); });
  }));
};

// ---------------- Clients & stores ----------------
VIEWS.clients = async v => {
  const [stores, settings] = await Promise.all([api('/api/stores'), api('/api/settings')]);
  v.innerHTML = `<h2>Clients &amp; stores</h2>
  <div class="card"><h3 style="margin-top:0">Clients</h3>
  ${state.clients.length ? `<div class="tablewrap"><table><tr><th>Name</th><th>Email</th><th class="n">Markup %</th><th class="n">Handling £</th><th></th></tr>
  ${state.clients.map(c => `<tr data-id="${c.id}"><td><input class="cn" value="${esc(c.name)}"></td><td><input class="ce" value="${esc(c.email || '')}"></td>
  <td class="n"><input class="cm" type="number" step="0.1" value="${c.markup_pct}" style="width:80px"></td><td class="n"><input class="ch" type="number" step="0.01" value="${c.handling_fee}" style="width:80px"></td>
  <td class="row"><button class="btn small cs">Save</button><button class="btn small ghost danger cd">Delete</button></td></tr>`).join('')}</table></div>` : ''}
  <form id="nc" class="form" style="margin-top:10px"><label>New client<input name="name" placeholder="Brand name" required></label><label>Email<input name="email" type="email"></label>
  <label>Markup %<input name="markup_pct" type="number" step="0.1" value="0"></label><label>Handling £<input name="handling_fee" type="number" step="0.01" value="0"></label><button class="btn primary">Add client</button></form></div>

  <div class="card" style="margin-top:12px"><h3 style="margin-top:0">Shopify stores</h3>
  <p class="muted">Each brand's store needs its own small app in your Shopify Dev Dashboard (Shopify only lets a private app install on one store). The setup guide walks through it — it takes about five minutes per store.</p>
  ${stores.length ? `<div class="tablewrap"><table><tr><th>Client</th><th>Store</th><th>Status</th><th>Last sync</th><th></th></tr>
  ${stores.map(s => `<tr><td>${esc(s.client)}</td><td>${esc(s.shop)}<br><span class="muted">${esc(s.auth_mode)}${s.webhooks_registered ? ' · live webhooks' : ''}</span></td>
  <td><span class="pill ${s.status === 'connected' ? 'ok' : s.status === 'error' ? 'short' : 'low'}">${esc(s.status)}</span>${s.status_note ? `<br><span class="muted">${esc(s.status_note)}</span>` : ''}
    ${s.status === 'pending' ? `<br><span class="muted">Send the brand this link to approve access:</span><br><code>${esc(s.install_link)}</code> <button class="btn small cp" data-l="${esc(s.install_link)}">Copy</button>` : ''}</td>
  <td>${when(s.last_synced_at)}</td><td class="row"><button class="btn small sy" data-id="${s.id}" ${s.has_token || s.auth_mode === 'client_credentials' ? '' : 'disabled'}>Sync now</button><button class="btn small ghost danger sd" data-id="${s.id}">Remove</button></td></tr>`).join('')}</table></div>` : '<p class="muted">No stores yet.</p>'}
  <form id="ns" class="form" style="margin-top:10px">
    <label>Client<select name="client_id">${state.clients.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label>
    <label>Store<input name="shop" placeholder="brand-name.myshopify.com" required></label>
    <label>How it connects<select name="auth_mode" id="am"><option value="oauth">Brand approves via link (normal)</option><option value="client_credentials">Store is in our Shopify org</option><option value="token">Paste an existing access token</option></select></label>
    <label class="app">App client ID<input name="app_client_id" placeholder="from Dev Dashboard → Settings"></label>
    <label class="app">App client secret<input name="app_client_secret" type="password"></label>
    <label class="tok hidden">Access token<input name="access_token" placeholder="shpat_…"></label>
    <label class="tok hidden">API secret (for webhooks)<input name="api_secret"></label>
    <button class="btn primary" ${state.clients.length ? '' : 'disabled'}>Add store</button></form></div>`;
  $('#nc', v).onsubmit = run(async e => { e.preventDefault(); const r = await api('/api/clients', { body: Object.fromEntries(new FormData(e.target)) }); await loadClients(); state.client = r.id; toast('Client added'); render(); });
  $$('.cs', v).forEach(b => b.onclick = run(async () => { const tr = b.closest('tr'); await api(`/api/clients/${tr.dataset.id}`, { method: 'PUT', body: { name: $('.cn', tr).value, email: $('.ce', tr).value, markup_pct: $('.cm', tr).value, handling_fee: $('.ch', tr).value } }); await loadClients(); toast('Saved'); }));
  $$('.cd', v).forEach(b => b.onclick = run(async () => {
    const tr = b.closest('tr'); const m = modal(`<h2>Delete ${esc($('.cn', tr).value)}?</h2><p>This removes the client with all their blanks, stock history, stores, orders and invoices. It can't be undone.</p><div class="row"><button class="btn primary danger" id="y">Delete everything</button><button class="btn ghost" data-close>Cancel</button></div>`);
    $('#y', m).onclick = run(async () => { await api(`/api/clients/${tr.dataset.id}`, { method: 'DELETE' }); closeModal(); await loadClients(); render(); });
  }));
  $('#am', v).onchange = e => { $$('.tok', v).forEach(x => x.classList.toggle('hidden', e.target.value !== 'token')); $$('.app', v).forEach(x => x.classList.toggle('hidden', e.target.value === 'token')); };
  $('#ns', v).onsubmit = run(async e => {
    e.preventDefault(); const body = Object.fromEntries(new FormData(e.target));
    const btn = $('button', e.target); btn.disabled = true;
    try { await api('/api/stores', { body }); toast(body.auth_mode === 'oauth' ? 'Store added — send the brand the approval link' : 'Store connected and synced'); } finally { btn.disabled = false; render(); }
  });
  $$('.cp', v).forEach(b => b.onclick = () => navigator.clipboard.writeText(b.dataset.l).then(() => toast('Link copied')));
  $$('.sy', v).forEach(b => b.onclick = run(async () => { b.disabled = true; const r = await api(`/api/stores/${b.dataset.id}/sync`, { body: {} }); toast(`${r.seen} orders checked, ${r.created} new`); render(); }));
  $$('.sd', v).forEach(b => b.onclick = run(async () => {
    const m = modal(`<h2>Remove this store?</h2><p>Its orders are removed from BlankStock too (stock already taken stays taken). You can add it again later.</p><div class="row"><button class="btn primary" id="y">Remove</button><button class="btn ghost" data-close>Cancel</button></div>`);
    $('#y', m).onclick = run(async () => { await api(`/api/stores/${b.dataset.id}`, { method: 'DELETE' }); closeModal(); render(); });
  }));
};

// ---------------- Settings ----------------
VIEWS.settings = async v => {
  const s = await api('/api/settings');
  const base = s._app_url || location.origin;
  v.innerHTML = `<h2>Settings</h2>
  <div class="card"><h3 style="margin-top:0">Your business (shown on top-up invoices)</h3>
  <form id="sf" class="form">
    <label>Business name<input name="biz_name" value="${esc(s.biz_name)}"></label>
    <label>Email<input name="biz_email" value="${esc(s.biz_email)}"></label>
    <label>VAT number<input name="vat_number" value="${esc(s.vat_number)}"></label>
    <label>VAT rate %<input name="vat_rate" type="number" value="${esc(s.vat_rate || '20')}"></label>
    <label>Invoice prefix<input name="invoice_prefix" value="${esc(s.invoice_prefix || 'TOP-')}"></label>
    <label>Next invoice no.<input name="next_invoice" type="number" value="${esc(s.next_invoice || '1')}"></label>
    <label style="grid-column:1/-1">Address<textarea name="biz_address" style="min-height:60px">${esc(s.biz_address)}</textarea></label>
    <label style="grid-column:1/-1">Payment terms<input name="payment_terms" value="${esc(s.payment_terms || 'Payment due within 7 days. Blanks are ordered once paid.')}"></label>
    <label style="grid-column:1/-1">Bank details<textarea name="bank_details" style="min-height:60px">${esc(s.bank_details)}</textarea></label>
    <button class="btn primary">Save</button></form></div>
  <div class="card" style="margin-top:12px"><h3 style="margin-top:0">Shopify app setup</h3>
  <p>For each brand's app in the Shopify Dev Dashboard, use these in the app version:</p>
  <table><tr><td>App URL</td><td><code>${esc(base)}/shopify/install</code></td></tr>
  <tr><td>Allowed redirection URL</td><td><code>${esc(base)}/shopify/callback</code></td></tr>
  <tr><td>Scopes</td><td><code>read_orders,read_products</code></td></tr>
  <tr><td>Embed in Shopify admin</td><td>Off</td></tr>
  <tr><td>Webhooks go to</td><td><code>${esc(base)}/webhooks</code> (registered automatically)</td></tr>
  <tr><td>API version</td><td><code>${esc(s._api_version)}</code></td></tr>
  <tr><td>Client ID &amp; secret</td><td>Entered per store under Clients &amp; stores${s._has_default_app ? ' (a default is also set in .env)' : ''}</td></tr></table>
  <div class="row" style="margin-top:12px"><button class="btn ghost" id="lo">Log out</button></div></div>`;
  $('#sf', v).onsubmit = run(async e => { e.preventDefault(); await api('/api/settings', { method: 'PUT', body: Object.fromEntries(new FormData(e.target)) }); toast('Saved'); });
  $('#lo', v).onclick = run(async () => { await api('/api/logout', { body: {} }); showLogin(); });
};

async function boot() {
  try { await loadClients(); } catch { return; }
  $('#app').classList.remove('hidden'); render();
}
boot();
