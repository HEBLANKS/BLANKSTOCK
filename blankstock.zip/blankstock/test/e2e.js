// End-to-end check: runs the real server against a throwaway database and fakes Shopify webhooks.
const assert = require('assert');
const crypto = require('crypto');
const os = require('os'), fs = require('fs'), path = require('path');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bs-'));
Object.assign(process.env, { DB_PATH: path.join(tmp, 't.db'), ADMIN_PASSWORD: 'pw', SESSION_SECRET: 'x', SHOPIFY_CLIENT_ID: 'cid', SHOPIFY_CLIENT_SECRET: 'shh', APP_URL: 'https://stock.example.com' });
const app = require('../src/server');
const { db } = require('../src/db');
const shopify = require('../src/shopify');

let base, cookie = '';
async function call(p, { method, body, raw, headers = {} } = {}) {
  const r = await fetch(base + p, { method: method || (body || raw ? 'POST' : 'GET'), headers: { 'Content-Type': 'application/json', cookie, ...headers }, body: raw ?? (body ? JSON.stringify(body) : undefined) });
  const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
  const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = t; }
  return { status: r.status, body: j };
}
let wid = 0;
function hook(topic, payload, secret = 'shh', id = `w${++wid}`) {
  const raw = JSON.stringify(payload);
  return call('/webhooks', { raw, headers: { 'X-Shopify-Topic': topic, 'X-Shopify-Shop-Domain': 'brand-a.myshopify.com', 'X-Shopify-Webhook-Id': id,
    'X-Shopify-Hmac-Sha256': crypto.createHmac('sha256', secret).update(raw).digest('base64') } });
}
const order = (id, name, lines, extra = {}) => ({ id, admin_graphql_api_id: `gid://shopify/Order/${id}`, name, created_at: new Date(Date.now() + id).toISOString(), cancelled_at: null,
  line_items: lines.map(([lid, variant, qty, sku]) => ({ id: lid, variant_id: variant, quantity: qty, current_quantity: qty, sku, title: 'Logo Tee', variant_title: 'Black / M' })), ...extra });
const stockOf = async (cid, size, colour = 'Jet Black') => (await call(`/api/clients/${cid}/stock`)).body.find(b => b.size === size && b.colour === colour);

(async () => {
  const srv = app.listen(0); base = `http://127.0.0.1:${srv.address().port}`;
  const ok = (name, fn) => fn().then(() => console.log('✓', name));

  await ok('login required, wrong password rejected, right one accepted', async () => {
    assert.equal((await call('/api/clients')).status, 401);
    assert.equal((await call('/api/login', { body: { password: 'nope' } })).status, 401);
    assert.equal((await call('/api/login', { body: { password: 'pw' } })).status, 200);
  });

  let cid;
  await ok('client + blanks via CSV, sizes normalised, deposit stock booked in', async () => {
    cid = (await call('/api/clients', { body: { name: 'Brand A', email: 'a@x.com', markup_pct: 10, handling_fee: 5 } })).body.id;
    const r = await call('/api/blanks', { body: { client_id: cid, csv: 'Style,Style name,Colour,Size,Qty,Cost,Reorder,Par\nAT001,AWDis 150,Jet Black,M,3,2.32,1,6\nat001,AWDis 150,Jet Black,xxl,2,2.32,1,4\nAT001,AWDis 150,Jet Black,L,0,2.32,1,4' } });
    assert.deepEqual(r.body, { rows: 3, units_booked: 5 });
    const r2 = await call('/api/blanks', { body: { client_id: cid, style_code: 'RX350', colour: 'Navy', size: 'S M L', qty: 4, unit_cost: 7.49 } });
    assert.equal(r2.body.rows, 3);
    assert.equal((await stockOf(cid, '2XL')).on_hand, 2);
    assert.equal((await stockOf(cid, 'M', 'Navy')).on_hand, 4);
  });

  const M = await stockOf(cid, 'M');
  db.prepare("INSERT INTO stores(client_id,shop,auth_mode,status) VALUES(?, 'brand-a.myshopify.com','oauth','connected')").run(cid);
  const storeId = db.prepare('SELECT id FROM stores').get().id;

  await ok('mapping a variant', async () => {
    assert.equal((await call('/api/map', { body: { store_id: storeId, variant_id: 'gid://shopify/ProductVariant/111', blank_id: M.id } })).status, 200);
  });

  await ok('webhook with bad signature is rejected', async () => {
    assert.equal((await hook('orders/create', order(1, '#1001', [[11, 111, 1]]), 'wrong')).status, 401);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM orders').get().n, 0);
  });

  await ok('order webhook takes stock; duplicate delivery ignored', async () => {
    assert.equal((await hook('orders/create', order(1, '#1001', [[11, 111, 2]]), 'shh', 'dup')).body, 'ok');
    assert.equal((await hook('orders/create', order(1, '#1001', [[11, 111, 2]]), 'shh', 'dup')).body, 'duplicate');
    assert.equal((await stockOf(cid, 'M')).on_hand, 1);
  });

  await ok('order bigger than stock is flagged short and blocked; stock goes negative', async () => {
    await hook('orders/create', order(2, '#1002', [[21, 111, 3]]));
    const s = await stockOf(cid, 'M'); assert.equal(s.on_hand, -2); assert.equal(s.status, 'short');
    const blocked = (await call(`/api/orders?status=blocked&client=${cid}`)).body;
    assert.equal(blocked.length, 1); assert.equal(blocked[0].name, '#1002'); assert.equal(blocked[0].lines[0].short_qty, 2);
    assert.equal((await call(`/api/orders?status=ready&client=${cid}`)).body.length, 1);
  });

  await ok('unmapped variant waits, then is processed when mapped (SKU fallback too)', async () => {
    await hook('orders/create', order(3, '#1003', [[31, 222, 1], [32, 333, 1, 'BRAND-NAVY-S']]));
    let un = (await call('/api/unmapped')).body; assert.equal(un.length, 2);
    // SKU auto-map: give the Navy S blank the brand's SKU, then a reprocess picks it up
    const navyS = await stockOf(cid, 'S', 'Navy');
    await call(`/api/blanks/${navyS.id}`, { method: 'PUT', body: { ...navyS, sku: 'BRAND-NAVY-S', active: 1 } });
    const twoXL = await stockOf(cid, '2XL');
    const r = await call('/api/map', { body: { store_id: storeId, variant_id: 'gid://shopify/ProductVariant/222', blank_id: twoXL.id, units: 2 } });
    assert.equal(r.body.reprocessed, 2);
    assert.equal((await call('/api/unmapped')).body.length, 0);
    assert.equal((await stockOf(cid, '2XL')).on_hand, 0);   // bundle: 1 sold × 2 units
    assert.equal((await stockOf(cid, 'S', 'Navy')).on_hand, 3);
  });

  await ok('non-garment product can be marked "don\'t track" and stops blocking', async () => {
    await hook('orders/create', order(7, '#1007', [[71, 777, 1, 'CAP-1']]));
    assert.equal((await call('/api/unmapped')).body.length, 1);
    const u = (await call('/api/unmapped')).body[0];
    assert.equal((await call('/api/ignore', { body: u })).body.reprocessed, 1);
    assert.equal((await call('/api/unmapped')).body.length, 0);
    await hook('orders/create', order(8, '#1008', [[81, 777, 2, 'CAP-1']]));
    assert.equal((await call('/api/unmapped')).body.length, 0);
    const o = (await call('/api/orders?q=%231008')).body[0]; assert.equal(o.blocked, false); assert.equal(o.lines[0].blank_id, null);
    await call('/api/orders/status', { body: { ids: [o.id, (await call('/api/orders?q=%231007')).body[0].id], status: 'dispatched' } });
  });

  await ok('cancelled order returns stock', async () => {
    await hook('orders/create', order(4, '#1004', [[41, 111, 1]]));
    assert.equal((await stockOf(cid, 'M')).on_hand, -3);
    await hook('orders/cancelled', order(4, '#1004', [[41, 111, 1]], { cancelled_at: new Date().toISOString() }));
    assert.equal((await stockOf(cid, 'M')).on_hand, -2);
    assert.equal((await call('/api/orders?status=cancelled')).body.length, 1);
  });

  let invId;
  await ok('top-up suggestion = shortfall + back to par; invoice priced with markup, VAT and handling', async () => {
    const s = await stockOf(cid, 'M'); assert.equal(s.suggest, 8); // -2 → par 6
    const L = await stockOf(cid, 'L'); assert.equal(L.suggest, 4);  // 0 ≤ reorder 1 → par 4
    await call('/api/settings', { method: 'PUT', body: { biz_name: 'Do It DTF', vat_rate: '20', bank_details: 'Sort 00-00-00' } });
    invId = (await call('/api/invoices', { body: { client_id: cid, lines: [{ blank_id: s.id, qty: 8 }, { blank_id: L.id, qty: 4 }] } })).body.id;
    const inv = (await call(`/api/invoices?client=${cid}`)).body[0];
    assert.equal(inv.number, 'TOP-0001'); assert.equal(inv.lines[0].unit_price, 2.55); // 2.32 × 1.10
    assert.equal(Math.round(inv.total * 100), Math.round((12 * 2.55 + 5) * 1.2 * 100));
    assert.equal((await stockOf(cid, 'M')).suggest, 0); // now on order, not suggested twice
    const html = await call(`/invoices/${invId}`); assert.match(html.body, /TOP-0001/); assert.match(html.body, /Do It DTF/);
    const csv = await call(`/invoices/${invId}.csv`); assert.match(csv.body, /Jet Black/);
  });

  await ok('booking in the top-up clears back-orders oldest first, order becomes ready', async () => {
    const inv = (await call(`/api/invoices?client=${cid}`)).body[0];
    const lineM = inv.lines.find(l => l.size === 'M');
    await call(`/api/invoices/${invId}/receive`, { body: { lines: [{ id: lineM.id, qty: 1 }] } }); // partial delivery
    assert.equal((await call(`/api/orders?status=blocked&client=${cid}`)).body[0].lines[0].short_qty, 1);
    await call(`/api/invoices/${invId}/receive`, { body: {} }); // rest arrives
    assert.equal((await call(`/api/orders?status=blocked&client=${cid}`)).body.length, 0);
    assert.equal((await stockOf(cid, 'M')).on_hand, 6);
    assert.equal((await stockOf(cid, 'L')).on_hand, 4);
  });

  await ok('stock take sets an exact count; order status workflow', async () => {
    const L = await stockOf(cid, 'L');
    await call(`/api/blanks/${L.id}/move`, { body: { qty: 3, mode: 'set' } });
    assert.equal((await stockOf(cid, 'L')).on_hand, 3);
    const ready = (await call(`/api/orders?status=ready&client=${cid}`)).body.map(o => o.id);
    await call('/api/orders/status', { body: { ids: ready, status: 'printed' } });
    assert.equal((await call(`/api/orders?status=printed`)).body.length, ready.length);
  });

  await ok('dashboard summary', async () => {
    const c = (await call('/api/summary')).body.clients[0];
    assert.equal(c.short_units, 0); assert.equal(c.blocked_orders, 0);
  });

  await ok('OAuth: install link only for known stores; callback rejects bad HMAC', async () => {
    const r = await fetch(base + '/shopify/install?shop=brand-a.myshopify.com', { redirect: 'manual' });
    assert.equal(r.status, 302); const loc = new URL(r.headers.get('location'));
    assert.equal(loc.host, 'brand-a.myshopify.com'); assert.equal(loc.searchParams.get('redirect_uri'), 'https://stock.example.com/shopify/callback');
    assert.equal((await fetch(base + '/shopify/install?shop=stranger.myshopify.com', { redirect: 'manual' })).status, 400);
    const q = { code: 'c', shop: 'brand-a.myshopify.com', state: loc.searchParams.get('state'), timestamp: '1' };
    const msg = Object.keys(q).sort().map(k => `${k}=${q[k]}`).join('&');
    assert.ok(shopify.verifyQueryHmac({ ...q, hmac: crypto.createHmac('sha256', 'shh').update(msg).digest('hex') }, 'shh'));
    assert.ok(!shopify.verifyQueryHmac({ ...q, hmac: 'bad' }, 'shh'));
    // per-store app credentials win over the .env default
    db.prepare("UPDATE stores SET app_client_id='store-app', app_client_secret='store-secret' WHERE shop='brand-a.myshopify.com'").run();
    const r2 = await fetch(base + '/shopify/install?shop=brand-a.myshopify.com', { redirect: 'manual' });
    assert.equal(new URL(r2.headers.get('location')).searchParams.get('client_id'), 'store-app');
    assert.equal((await hook('orders/create', order(90, '#1090', [[901, 111, 1]]), 'store-secret')).status, 200);
    assert.equal((await call('/api/stores', { body: { client_id: cid, shop: 'new-brand', auth_mode: 'oauth', app_client_id: 'a2', app_client_secret: 's2' } })).status, 200);
    assert.equal(db.prepare("SELECT app_client_id FROM stores WHERE shop='new-brand.myshopify.com'").get().app_client_id, 'a2');
    assert.equal((await fetch(base + '/shopify/callback?' + new URLSearchParams({ ...q, hmac: 'bad' }))).status, 400);
  });

  await ok('GraphQL order shape normalises the same as webhook shape', async () => {
    const g = shopify.fromGraphql('brand-a.myshopify.com', { id: 'gid://shopify/Order/9', name: '#9', createdAt: 'x', cancelledAt: null,
      lineItems: { nodes: [{ id: 'gid://shopify/LineItem/1', sku: 'S', title: 'T', variantTitle: 'V', quantity: 2, currentQuantity: 1, variant: { id: 'gid://shopify/ProductVariant/5' } }] } });
    const w = shopify.fromWebhook('brand-a.myshopify.com', { id: 9, name: '#9', created_at: 'x', line_items: [{ id: 1, sku: 'S', title: 'T', variant_title: 'V', quantity: 2, current_quantity: 1, variant_id: 5 }] });
    assert.deepEqual(g, w); assert.equal(g.adminUrl, 'https://admin.shopify.com/store/brand-a/orders/9');
  });

  srv.close(); console.log('\nAll checks passed.');
})().catch(e => { console.error('✗', e); process.exit(1); });
