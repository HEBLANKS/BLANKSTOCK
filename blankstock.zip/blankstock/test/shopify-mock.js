// Checks the Shopify client against a fake Shopify (token grant, paging, webhook registration).
const assert = require('assert'); const os = require('os'), fs = require('fs'), path = require('path');
Object.assign(process.env, { DB_PATH: path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'bs-')), 't.db'), SHOPIFY_CLIENT_ID: 'cid', SHOPIFY_CLIENT_SECRET: 'shh', APP_URL: 'https://stock.example.com' });
const { db } = require('../src/db'); const shopify = require('../src/shopify'); const stock = require('../src/stock');
const calls = [];
global.fetch = async (url, opts) => {
  const body = opts.body instanceof URLSearchParams ? Object.fromEntries(opts.body) : JSON.parse(opts.body || '{}');
  calls.push({ url, body, token: opts.headers['X-Shopify-Access-Token'] });
  const J = o => ({ ok: true, status: 200, json: async () => o, text: async () => JSON.stringify(o) });
  if (url.endsWith('/admin/oauth/access_token')) return J({ access_token: 'tok1', scope: 'read_orders', expires_in: 86399 });
  const q = body.query;
  if (q.includes('orders(')) {
    const page = body.variables.after ? 2 : 1;
    const n = id => ({ id: `gid://shopify/Order/${id}`, name: `#${id}`, createdAt: new Date().toISOString(), cancelledAt: id === 3 ? new Date().toISOString() : null,
      lineItems: { nodes: [{ id: `gid://shopify/LineItem/${id}`, sku: 'SKU-M', title: 'Tee', variantTitle: 'M', quantity: 1, currentQuantity: 1, variant: { id: 'gid://shopify/ProductVariant/1' } }] } });
    return J({ data: { orders: { pageInfo: { hasNextPage: page === 1, endCursor: 'c1' }, nodes: page === 1 ? [n(1), n(2)] : [n(3)] } } });
  }
  if (q.includes('webhookSubscriptions(')) return J({ data: { webhookSubscriptions: { nodes: [{ id: 'x', topic: 'ORDERS_CREATE', uri: 'https://stock.example.com/webhooks' }] } } });
  if (q.includes('webhookSubscriptionCreate')) return J({ data: { webhookSubscriptionCreate: { userErrors: [] } } });
  throw new Error('unexpected ' + q);
};
(async () => {
  const cid = db.prepare("INSERT INTO clients(name) VALUES('A')").run().lastInsertRowid;
  const bid = db.prepare("INSERT INTO blanks(client_id,style_code,colour,size,sku) VALUES(?,'AT001','Black','M','SKU-M')").run(cid).lastInsertRowid;
  stock.addMovement(bid, 5, 'intake');
  const sid = db.prepare("INSERT INTO stores(client_id,shop,auth_mode) VALUES(?,'a.myshopify.com','client_credentials')").run(cid).lastInsertRowid;
  const s = () => db.prepare('SELECT * FROM stores WHERE id=?').get(sid);
  await shopify.registerWebhooks(s());
  const created = calls.filter(c => c.body.query?.includes('webhookSubscriptionCreate')).map(c => c.body.variables.topic);
  assert.deepEqual(created, ['ORDERS_CANCELLED', 'APP_UNINSTALLED']); console.log('✓ registers only missing webhooks');
  assert.equal(calls[0].body.grant_type, 'client_credentials'); assert.equal(s().access_token, 'tok1'); console.log('✓ client-credentials token fetched and cached');
  const r = await shopify.syncStore(s()); assert.deepEqual(r, { seen: 3, created: 3 }); console.log('✓ sync pages through orders');
  assert.equal(stock.onHand(bid), 3); console.log('✓ SKU auto-map deducted 2, cancelled order netted to 0');
  const r2 = await shopify.syncStore(s()); assert.equal(r2.created, 0); assert.equal(stock.onHand(bid), 3); console.log('✓ re-sync is idempotent');
  assert.equal(calls.filter(c => c.url.includes('access_token')).length, 1); console.log('✓ token reused, not re-requested');
  console.log('\nShopify client checks passed.');
})().catch(e => { console.error('✗', e); process.exit(1); });
